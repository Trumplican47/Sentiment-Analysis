# End-to-End Sentiment Analysis System Using NLP & Machine Learning

## Project Overview

This project builds an end-to-end sentiment analysis system that classifies raw movie review text as either Positive or Negative. The workflow includes data ingestion, exploratory data analysis, text preprocessing, feature engineering, machine learning model training, model evaluation, model optimization, final model selection, and an inference pipeline for real-world predictions.

## Dataset Description

- **Dataset:** IMDb Movie Reviews
- **Source:** Hugging Face `imdb` dataset
- **Number of Samples Used:** 25,000 training reviews from the IMDb training split
- **Input Feature:** `text` - the raw movie review text
- **Target Variable:** `label` - sentiment class where `0 = Negative` and `1 = Positive`
- **Sentiment Classes:** Negative and Positive

The dataset is appropriate for this project because it contains more than 10,000 labeled text samples and is commonly used for binary sentiment classification.

## Project Workflow

1. **Data Ingestion and Understanding**
   - Loaded the IMDb dataset.
   - Inspected column names, data types, missing values, duplicates, and class distribution.

2. **Exploratory Data Analysis**
   - Visualized sentiment class distribution.
   - Created a review length feature.
   - Analyzed review length distribution.
   - Generated word frequency plots.
   - Generated a WordCloud to visualize common words.

3. **Text Preprocessing**
   - Converted text to lowercase.
   - Removed HTML tags.
   - Removed punctuation and numbers.
   - Tokenized text into individual words.
   - Removed stopwords.
   - Applied lemmatization using WordNetLemmatizer.

4. **Feature Engineering**
   - Created Bag of Words features using `CountVectorizer`.
   - Created TF-IDF features using `TfidfVectorizer`.
   - Compared model performance using numerical text representations.

5. **Model Training**
   - Trained Logistic Regression.
   - Trained Multinomial Naive Bayes.
   - Trained Random Forest Classifier.

6. **Model Evaluation**
   - Evaluated models using Accuracy, Precision, Recall, F1 Score, Confusion Matrix, and Cross-Validation.
   - Compared all model results in a table.

7. **Model Optimization**
   - Performed hyperparameter tuning using GridSearchCV.
   - Tuned the Logistic Regression regularization parameter `C`.

8. **Inference Pipeline**
   - Built a reusable function that accepts raw text, preprocesses it, transforms it with TF-IDF, and predicts sentiment.

## Model Results and Final Selection

After training multiple models, including Logistic Regression, Naive Bayes, and Random Forest, the best performance came from Logistic Regression.

| Model | Accuracy | Precision | Recall | F1 Score |
|---|---:|---:|---:|---:|
| Logistic Regression | 0.8842 | 0.8734 | 0.8970 | 0.8851 |
| Naive Bayes | 0.8532 | 0.8481 | 0.8584 | 0.8532 |
| Random Forest | 0.8500 | 0.8508 | 0.8467 | 0.8487 |

Additional Logistic Regression results:

- **Best Model:** Logistic Regression
- **Best Hyperparameter:** `C = 1`
- **5-Fold Cross-Validation Accuracy:** 0.8624
- **Confusion Matrix:**
  - True Negatives: 2,192
  - False Positives: 323
  - False Negatives: 256
  - True Positives: 2,229

Logistic Regression was selected because it achieved the highest accuracy and F1 score while remaining fast, interpretable, and efficient for text classification.

## How to Run the Project

1. Clone or download the project folder.
2. Install dependencies:

```bash
pip install -r requirements.txt
```

3. Open the notebook:

```text
notebooks/eda_and_modeling.ipynb
```

4. Run all notebook cells from top to bottom.

5. To use the saved inference pipeline after training:

```bash
python src/inference.py
```

6. To run the optional Streamlit app:

```bash
streamlit run app.py
```

## Project Structure

```text
project/
├── data/
├── notebooks/
│   └── eda_and_modeling.ipynb
├── src/
│   ├── preprocessing.py
│   ├── feature_engineering.py
│   ├── model_training.py
│   └── inference.py
├── models/
│   └── trained_model.pkl
├── outputs/
│   └── evaluation_results/
├── requirements.txt
├── README.md
└── report.pdf
```

## Limitations

The model performs well on English movie reviews but may struggle with sarcasm, slang, complex negations, multilingual reviews, or domains outside movie reviews. Future improvements could include transformer-based models, better negation handling, larger feature spaces, and multilingual embeddings.
