"""Feature engineering utilities for BoW and TF-IDF."""

from sklearn.feature_extraction.text import CountVectorizer, TfidfVectorizer


def create_bow_features(text_series, max_features=5000):
    vectorizer = CountVectorizer(max_features=max_features)
    features = vectorizer.fit_transform(text_series)
    return features, vectorizer


def create_tfidf_features(text_series, max_features=5000):
    vectorizer = TfidfVectorizer(max_features=max_features)
    features = vectorizer.fit_transform(text_series)
    return features, vectorizer
