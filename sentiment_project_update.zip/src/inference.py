"""Inference pipeline for predicting sentiment on new reviews."""

import joblib
from preprocessing import clean_text


def load_artifacts(model_path="../models/trained_model.pkl", vectorizer_path="../models/tfidf_vectorizer.pkl"):
    model = joblib.load(model_path)
    vectorizer = joblib.load(vectorizer_path)
    return model, vectorizer


def predict_sentiment(review: str, model, vectorizer) -> str:
    cleaned_review = clean_text(review)
    review_vector = vectorizer.transform([cleaned_review])
    prediction = model.predict(review_vector)[0]
    return "Positive" if prediction == 1 else "Negative"


if __name__ == "__main__":
    model, vectorizer = load_artifacts()
    sample_review = "This movie was fantastic and very entertaining."
    print(predict_sentiment(sample_review, model, vectorizer))
