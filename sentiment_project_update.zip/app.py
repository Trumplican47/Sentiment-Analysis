"""Simple Streamlit app for the sentiment analysis model."""

import streamlit as st
import joblib
from src.preprocessing import clean_text

st.title("Sentiment Analysis App")
st.write("Enter a movie review and the model will predict whether it is Positive or Negative.")

review = st.text_area("Review Text")

if st.button("Predict"):
    model = joblib.load("models/trained_model.pkl")
    vectorizer = joblib.load("models/tfidf_vectorizer.pkl")
    cleaned = clean_text(review)
    vectorized = vectorizer.transform([cleaned])
    prediction = model.predict(vectorized)[0]
    sentiment = "Positive" if prediction == 1 else "Negative"
    st.success(f"Predicted Sentiment: {sentiment}")
